import * as views from './views.js'
import {Model} from './model.js'
import { Auth } from './service.js';

window.addEventListener("modelUpdated", function(e) {
    let posts = Model.getPosts();
    let popularPost = Model.getPopularPosts();
    let recentPosts = Model.getRecentPosts();
    let random = Model.getRandomPosts();
    views.listView("list", posts, popularPost,recentPosts,random)
    bindings();
})

window.addEventListener("personAdded", function(e) {
    let posts = Model.getPosts();
    views.listView("list", posts)
    bindings();
}
);

window.addEventListener("commentAdded", function(e) {
    let posts = Model.getPosts();
    views.listView("list", posts)
    bindings();
}
);

window.addEventListener('userLogin', function(e) {
    console.log('userLgin triggered')
    console.log('the user name is ', Auth.getUser())
    views.loginView('login', Auth.getUser())
})


function posts_click_handler () {
    let id = this.dataset.id
    let person = Model.getPost(Number(id))
    views.postsView("person", person)
}

function posts_form_handler(event){
    
    event.preventDefault()
    console.log(this)

    const p_author = this.elements['p_author'].value
    const p_likes = this.elements['p_likes'].value
    const p_url = this.elements['p_url'].value
    const p_caption = this.elements['p_caption'].value

    const p_image = this.elements['p_image'].files[0]

    const postsData = {
        "p_author": p_author,
        "p_likes": p_likes,
        "p_url": p_url,
        "p_caption": p_caption,
    }
    const pictureData = new FormData()
    pictureData.append("files", p_image)

    Model.addPost(pictureData, postsData)

}

function login_form_handler (event) {
    event.preventDefault()

    const username = this.elements['username'].value
    const password = this.elements['password'].value
    const authInfo = {
        'identifier': username,
        'password': password
    }
    Auth.login(authInfo)
}

function bindings() {
    
    let names = document.getElementsByClassName("person-name")
    for (let i=0; i<names.length; i++) {
        names[i].onclick = posts_click_handler
    }

    let form = document.getElementById('person-form')
    form.onsubmit = posts_form_handler

    if (!Auth.getUser()) {
        let loginform = document.getElementById('login-form')
        loginform.onsubmit = login_form_handler
    }    

}


window.onload = function (){
    Model.load();
    views.loginView('login', Auth.getUser())
}