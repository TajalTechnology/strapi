export {Model};
import {Auth} from './service.js'

const Model = {
    posts_url:"/posts",
    comments_url:"/comments",
    upload_url: "/upload",

    data:{
        posts:[],
        comments:[],
    },

    load: function(){
        fetch(this.posts_url)
        .then(
            function(response){
                return response.json(); 
            }
        )
        .then(
            (data) => {
                this.data.posts = data
                let event = new CustomEvent("modelUpdated",{detail:this});
                window.dispatchEvent(event)
            }
        )
    }, 
        // addComment - add a comment to a post 
    //      by submitting a POST request to the server API
    //      commentData is an object containing the content of the comment, the author and the postid
    // when the request is resolved, creates an "commentAdded" event
    addComment: function (commentData) {
        fetch(this.comments_url,{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body: JSON.stringify(commentData)
        })
        .then((response) =>{
            return response.json();
        })
        .then((data)=>{
            this.comments.push(data);
            let event = new CustomEvent('commentAdded');
            window.dispatchEvent(event)
        })
    },

    addPost: function (pictureData, postsData){
        fetch(this.upload_url, {
            method: 'POST',
            body: pictureData
        })
        .then((response) => {
            return response.json()
        })
        .then((data) => {
            console.log('the data is ', data)
            postsData = {...postsData, "p_image": data[0]}
            return fetch(this.posts_url, {
                method: 'POST',
                headers: {
                'Content-Type': 'application/json',
                },
                body: JSON.stringify(postsData)
            })
        })
        .then((response) => {
            return response.json()
        })
        .then((data) => {
            console.log(data)
            this.data.posts.push(data)
            let event = new CustomEvent('personAdded');
            window.dispatchEvent(event)
        })
    },

    getPosts: function() {
        return this.data.posts
    },

    getPost: function(id){
        let posts =  this.getPosts()

        for(let i=0; i<posts.length; i++) {
            if (posts[i].id === id) {
                return posts[i]
            }
        }
    },

    setPosts: function(posts) {
        this.data.posts = posts;
    },

    getRandomPosts: function(){
        fetch(this.posts_url)
        .then(
            function(response){
            //parse it into json and return it back
                return response.json(); 
            }
        )
        .then((list) => { 
            this.data.posts = list
        })
        // console.log('123',this.data.posts);
        // var randomNums = [];
        var list = this.data.posts;
        var result = [];
        for (var i = 0; i < 3; i++) {
            result.push(list.splice(Math.random() * (list.length - 1), 3).pop());
        }
        return result;

    },

    // getRecentPosts - return the N most recent as an array
    //  posts, ordered by timestamp, most recent first
    getRecentPosts: function() {

        function recentPost(m, n) {
            if (m.published_at > n.published_at) {
                return -1;
            } else if (m.published_at === n.published_at) {
                return 0;
            } else {
                return 1;
            }
        }

        const result = this.data.posts.slice();
        result.sort(recentPost);
        return result.slice(0, 10);
    },

    // getPopularPosts - return the N most popular as an array
    // posts, ordered by the number of likes
    getPopularPosts: function(N) {

        function popularPost(m, n) {
            if (m.p_likes < n.p_likes) {
                return -1;
            } else if (m.p_likes === n.p_likes) {
                return 0;
            } else {
                return 1;
            }
        }

        const result = this.data.posts.slice();
        result.sort(popularPost);
        result.reverse();
        return result.slice(0, 10);
    },
}