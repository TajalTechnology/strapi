export {listView, postsView, loginView,}

//applyTemplate - apply a template to some data
// and insert into the pge
// targetid - id of the element to insert content
// templateid - id of the element containing the template
// data - data to pass to the template
function applyTemplate (targetid, templateid, data) {
    let target = document.getElementById(targetid)
    
    let template = Handlebars.compile(
        document.getElementById(templateid).textContent
    )

    target.innerHTML = template(data)
}

function listView (targetid,  posts,popularPost,recentPosts,random) {
    applyTemplate(targetid, "posts-list-template", {"posts": posts, "popularPost":popularPost,"recentPosts":recentPosts,"random":random})

}

//listpostsView - generate a view of an individual person
// and insert it as 'targetid' in the document
function postsView(targetid, person) {

    applyTemplate(targetid, "person-template", person)

}

//loginView - display the username or loginform based on the login status
function loginView (targetid, user) {
    applyTemplate(targetid, 'login-template', {"user": user})
}
